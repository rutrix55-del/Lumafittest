// LumaFit — landing page interactions

// Nav shadow on scroll
const nav = document.getElementById('nav');
const onScroll = () => {
    if (window.scrollY > 8) nav.classList.add('scrolled');
    else nav.classList.remove('scrolled');
};
window.addEventListener('scroll', onScroll, { passive: true });
onScroll();

// Reveal-on-scroll for major elements
const revealTargets = document.querySelectorAll(
    '.hero-title, .hero-sub, .hero-cta, .hero-stats, ' +
    '.problem-card, .problem-lead, .inside-card, .benefit, ' +
    '.for-who-card, .testimonial, .buy-card, .faq-item'
);
revealTargets.forEach(el => el.classList.add('reveal'));

const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            io.unobserve(entry.target);
        }
    });
}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

revealTargets.forEach(el => io.observe(el));

// ── Checkout configuration ───────────────────────────────────────────
// CHECKOUT_URL works with EITHER a Stripe Payment Link OR a Merchant-of-
// Record checkout (Lemon Squeezy / Gumroad). It's just the URL the buyer
// is sent to. To go live:
//   1. Create your $15 product + checkout in your chosen platform.
//   2. Paste its checkout URL into CHECKOUT_URL below.
//   3. Set CHECKOUT_READY = true and redeploy.
// A public checkout URL in client JS is safe. NEVER put a Stripe SECRET
// key (sk_live_…) anywhere in this file — only the public checkout URL.
const CHECKOUT_READY = false;
const CHECKOUT_URL = 'https://REPLACE_ME';

const buyBtn = document.getElementById('buyBtn');
const ageConfirm = document.getElementById('ageConfirm');

// Buyer must confirm they're 18+/a guardian before the button enables.
function syncBuyState() {
    if (!buyBtn) return;
    const ok = !ageConfirm || ageConfirm.checked;
    buyBtn.disabled = !ok;
    buyBtn.classList.toggle('is-disabled', !ok);
}
if (ageConfirm) ageConfirm.addEventListener('change', syncBuyState);
syncBuyState();

if (buyBtn) {
    buyBtn.addEventListener('click', () => {
        if (ageConfirm && !ageConfirm.checked) {
            ageConfirm.focus();
            return;
        }
        if (CHECKOUT_READY) {
            window.location.href = CHECKOUT_URL;
        } else {
            alert('Checkout opens soon — LumaFit is launching shortly.');
        }
    });
}
